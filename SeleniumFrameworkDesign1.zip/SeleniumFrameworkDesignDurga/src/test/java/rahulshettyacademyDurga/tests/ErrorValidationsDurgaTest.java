package rahulshettyacademyDurga.tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import rahulshettyacademyDurga.TestComponents.BaseTest;
import rahulshettyacademyDurga.pageobjects.CartPage;
import rahulshettyacademyDurga.pageobjects.ProductCataloguePage;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

import org.apache.hc.core5.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
@Test
public class ErrorValidationsDurgaTest extends BaseTest{
     //getting landingpage by landingpage class and incorrect credentials sending
	//write method and mark it with Test 
	@Test(groups={"ErrorHandling"})
	public void LoginErrorValidation() {
	 ProductCataloguePage productCataloguePage=landingPage.loginApplication("priyaee81@gmail.com", "Chegg@123");
	 String t=landingPage.getErrorMeassage();
	 Assert.assertEquals("Incorrect email or password.",t);
	}
	
	public void ProductErrorValidation() throws InterruptedException {
		/*getting the productlist in cartpage and checking whether product matched with 
		 * product selected in productCataloguePage*/
		ProductCataloguePage productCataloguePage=landingPage.loginApplication("priyaeee81@gmail.com", "Chegg@123");
		List<WebElement> productsList=productCataloguePage.getProductList();
		productCataloguePage.addProductToCart("ZARA COAT 3");
		CartPage cartpage=productCataloguePage.goToCartPage();
		Boolean match=cartpage.verifyProductDisplay("ZARA COAT 3");
		Assert.assertFalse(match);
	}
	}


