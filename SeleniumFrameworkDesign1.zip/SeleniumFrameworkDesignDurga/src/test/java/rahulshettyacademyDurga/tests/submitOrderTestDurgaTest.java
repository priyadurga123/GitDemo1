package rahulshettyacademyDurga.tests;
import rahulshettyacademyDurga.TestComponents.BaseTest;
import rahulshettyacademyDurga.pageobjects.CartPage;
import rahulshettyacademyDurga.pageobjects.CheckoutPage;
import rahulshettyacademyDurga.pageobjects.ConfirmationPage;
import rahulshettyacademyDurga.pageobjects.LandingPage;
import rahulshettyacademyDurga.pageobjects.OrderPage;
import rahulshettyacademyDurga.pageobjects.ProductCataloguePage;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

public class submitOrderTestDurgaTest extends BaseTest{

  @Test
  public void submitOrderTest() throws IOException, InterruptedException {
	  //LandingPage landingPage=launchApplication();(variable made public in baseTest
		 ProductCataloguePage productCataloguePage=landingPage.loginApplication("priyaeee81@gmail.com", "Chegg@123");//catching return
		
		//calling methods in productCataloguePage
		List<WebElement> products=productCataloguePage.getProductList();
		productCataloguePage.addProductToCart("ZARA COAT 3");
		
		/*going to cart page and validating whether product is in cart page or not*/
		CartPage cartPage=productCataloguePage.goToCartPage();
		Boolean match=cartPage.verifyProductDisplay("ZARA COAT 3");
		Assert.assertTrue(match);
		CheckoutPage checkoutPage=cartPage.goToCheckout();
		/*going to checkout page and entering required details for billing payment*/
		checkoutPage.selectCountry("india");
		/*going to confirmation page and verifying thanku mes*/
		/* ConfirmationPage confirmationPage=checkoutPage.submitOrder();
		 String confirmMessage=confirmationPage.verifyConfirmationMessage();
		 Assert.assertTrue(confirmMessage.equalsIgnoreCase("THANKYOU FOR THE ORDER."));*/
  }
  @Test(dependsOnMethods={"submitOrderTest"})
  public void  order() {
	  ProductCataloguePage productCataloguePage=landingPage.loginApplication("priyaeee81@gmail.com", "Chegg@123");
	  OrderPage orderpage=productCataloguePage.goToOrdersPage();
	  Boolean v=orderpage.verifyOrderDisplay("ZARA COAT 3");
	  System.out.println(v);
	  Assert.assertFalse(v);
}
}

