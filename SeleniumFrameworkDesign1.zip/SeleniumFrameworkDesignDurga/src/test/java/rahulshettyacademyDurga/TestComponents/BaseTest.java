package rahulshettyacademyDurga.TestComponents;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;
import rahulshettyacademyDurga.pageobjects.LandingPage;

public class BaseTest {
	public WebDriver driver ;
	public LandingPage landingPage;
	public WebDriver intializeDriver() throws IOException {//intializing driver here,instead of creating it in test file.and using properties class to select driver
		
		Properties pro=new Properties();
		FileInputStream fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\rahulshettyacademyDurga\\resources\\GolbalData.properties");
		System.out.println(System.getProperty("user.dir"));
		pro.load(fis);
		String browserName=pro.getProperty("browser");
		if(browserName.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			 driver =new ChromeDriver();
		}else if(browserName.equalsIgnoreCase("edge")){
			WebDriverManager.chromedriver().setup();
			driver =new EdgeDriver();
			
		}else if(browserName.equalsIgnoreCase("firefox")) {
			WebDriverManager.chromedriver().setup();
			 driver =new FirefoxDriver();
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		return driver;
		
	}
	@BeforeMethod(alwaysRun=true)
	public LandingPage launchApplication() throws IOException {
		driver=intializeDriver();
		landingPage=new LandingPage(driver);//created landingpage object,inorder to remove it in test file(SOTD file)
		landingPage.goTo();
		return landingPage;
	}
	@AfterMethod(alwaysRun=true)
	public void tearDown() {driver.close();}

}
