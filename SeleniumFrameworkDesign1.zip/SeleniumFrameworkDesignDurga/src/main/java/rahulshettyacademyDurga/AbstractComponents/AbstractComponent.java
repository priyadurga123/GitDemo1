package rahulshettyacademyDurga.AbstractComponents;
import java.time.Duration;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import rahulshettyacademyDurga.pageobjects.CartPage;
import rahulshettyacademyDurga.pageobjects.OrderPage;


public class AbstractComponent {
	WebDriver driver;
	public AbstractComponent(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="[routerlink*='cart']")
	WebElement cartHeader;
	@FindBy(css="[routerlink*='myorders']")
	WebElement orderHeader;
	
	public void waitForElementToAppear(By findBy) {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(findBy));
	}
	public void waitFoWebrElementToAppear(WebElement ele) {//created to use in error validation calling method
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOf(ele));
	}
	public void waitForElementToDisappear(WebElement ele) throws InterruptedException {
		/*WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.invisibilityOf(ele));*/
		Thread.sleep(2000);//using direct to sleep,to remove backend loading 
	}
	/*As cart icon common to all web pages so creating in Abstract class*/
	public CartPage goToCartPage() {//clicking on cart icon
		cartHeader.click();
		CartPage cartPage=new CartPage(driver);//creating cartPage here,instead of creating in test file.
		return cartPage;
	}
	public OrderPage goToOrdersPage() {
		 orderHeader.click();
		OrderPage orderpage=new OrderPage(driver);
		return orderpage;
		
	}

}
