package rahulshettyacademyDurga.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import rahulshettyacademyDurga.AbstractComponents.AbstractComponent;

public class CheckoutPage extends AbstractComponent{
WebDriver driver;
public CheckoutPage(WebDriver driver) {
	super(driver);
	this.driver=driver;
	PageFactory.initElements(driver,this);
}
@FindBy(css=".action__submit") WebElement submit;
@FindBy(css="[placeholder='Select Country']") WebElement country;
@FindBy(xpath="//section/button[1]") WebElement selectCountry;

public void selectCountry(String countryName) {
	Actions a = new Actions(driver);
	a.sendKeys(country,countryName).build().perform();//elimating hard coding by using countryName variable
	waitForElementToAppear(By.cssSelector(".ta-results"));//dropdown to get open,using abstractComponent
	selectCountry.click();//clicking one of dropdown option
}
public ConfirmationPage submitOrder() throws InterruptedException {Thread.sleep(2000);
	submit.click();
	
return new ConfirmationPage(driver);
}
}
