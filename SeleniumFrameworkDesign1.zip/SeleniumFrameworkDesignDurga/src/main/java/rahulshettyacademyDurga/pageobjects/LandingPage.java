package rahulshettyacademyDurga.pageobjects;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import rahulshettyacademyDurga.AbstractComponents.AbstractComponent;


public class LandingPage extends  AbstractComponent{
	WebDriver driver;
	public LandingPage(WebDriver driver) {
		super(driver);//invoking abstractComponent constructor
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	//Declaring the elements in pagefactory model in order remove those  elements in Test page 
	@FindBy(id="userEmail")
	WebElement userEmail;
	
	@FindBy(id="userPassword")
	WebElement userPassword;
	
	@FindBy(id="login")
	WebElement submit;
	
	@FindBy(css="[class*='flyInOut']")
	WebElement errorMessage;//error message popup if wrong details entered.
	
	//creating login functionality in  order to call by Test
	public ProductCataloguePage loginApplication(String email,String password) {
		userEmail.sendKeys(email); userPassword.sendKeys(password);submit.click();
		ProductCataloguePage productCataloguePage=new ProductCataloguePage(driver);//creating next page object,instead of creating in test file.
		return productCataloguePage;
	}
   
	public void goTo() {
		driver.get("https://rahulshettyacademy.com/client");
	}
	public String getErrorMeassage() {//method to check whether the text is equal on element 
		waitFoWebrElementToAppear(errorMessage);
		return errorMessage.getText();
	}
}


